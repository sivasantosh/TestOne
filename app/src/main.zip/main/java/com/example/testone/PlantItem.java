package com.example.testone;

public class PlantItem {
    String common, botanical, zone, light, price, availability;

    PlantItem (String c, String b, String z, String l, String p, String a) {
        common = c;
        botanical = b;
        zone = z;
        light = l;
        price = p;
        availability = a;
    }
}
